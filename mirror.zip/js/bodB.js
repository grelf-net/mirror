// Copyright (c) Graham Relf, UK, 2020-24
// www.grelf.net
'use strict';

function createBod(x, y, z, bDegs)
{ var colour = {r:100, g:200, b:100};
  var bodyzC = z + 2.5, bodyhHt = 2, bodyzT = bodyzC + bodyhHt;
  var bodyhWd = 1.25, bodyhDp = 0.5;
  var body = new Cuboid(x, y, bodyzC, bodyhWd, bodyhDp, bodyhHt);
  body.setColour(colour.r, colour.g, colour.b);
  var headzC = bodyzC + 3, headhHt = 0.75, headzB = headzC - headhHt;
  var head = new Icosahedron(x, y, headzC, headhHt);
  head.setColour(colour.r, colour.g, colour.b);
  head.faces[3].setColour (255, 255, 0);//Eye
  head.faces[4].setColour (255, 255, 0);
  var neckTh = 0.15, neckLen = headzB - bodyzT + 0.02;
  var neck = new Prism(x, y, (headzB + bodyzT) / 2, neckLen / 2, 
  [{x:x - neckTh, y:y - neckTh},
   {x:x + neckTh, y:y - neckTh},
   {x:x + neckTh, y:y + neckTh},
   {x:x - neckTh, y:y + neckTh}]);
  neck.setColour(colour.r, colour.g, colour.b);
  var bodyzB = bodyzC - bodyhHt, legzC = bodyzB / 2;
  var bodyqWd = bodyhWd / 2;
  var lLegxC = x + bodyqWd, rLegxC = x - bodyqWd, leghTh = bodyhDp * 0.6;
  var lLeg = createHexagon(lLegxC, y, leghTh).extrude(bodyzB);
  lLeg.setColour(colour.r, colour.g, colour.b);
  var rLeg = createHexagon(rLegxC, y, leghTh).extrude(bodyzB);
  rLeg.setColour(colour.r, colour.g, colour.b);
  var bod = new Bod([body, head, neck, lLeg, rLeg]);
  bod.centre = new Point3D(x, y, bodyzC);
  bod.zc0 = bodyzC;// Initial centre, on ground
  bod.bRad = bDegs * DEG2RAD;
  bod.rotateZ(bDegs);
  bod.isTarget = true;
  bod.response = function() { this.swapWithViewer(); hint("Alter ego?")};
  return bod;
}

//So instanceof shows Bod, not Composite:
function Bod (parts) { Composite.call(this, parts); }
Bod.prototype = Object.create(Composite.prototype);
Bod.prototype.constructor = Bod;

Bod.prototype.checkGround = function()
{ if (this.centre.z < this.zc0) this.translate(0, 0, this.zc0 - this.centre.z);
};

Bod.prototype.swapWithViewer = function()
{ var bodX = this.centre.x, bodY = this.centre.y, bodZ = this.centre.z, bodRad = this.bRad;
  var meX = me.pt.x, meY = me.pt.y, meZ = me.pt.z, meRad = me.bRad;
  me.pt = new Point3D(bodX, bodY, 10.5);//On ground
  me.bRad = bodRad;
  me.bod = this;//B
  this.bRad = meRad;
  if (!world.house.outside(this.centre))
  { if (!this.bodScored)
    { world.score += 500; this.bodScored = true;
  } }
  // On ground?
  var rv = this.vertices, minZ = 1000000;
  for (var i = 0; i < rv.length; i++) { if (rv[i].z < minZ) minZ = rv[i].z; }
  if (minZ < 10) this.translate(0, 0, -minZ);
  else if (minZ > 10) // fall slowly:
  { world.animData = {bod:this, z:minZ, dz:-1};
    bodFall();
  }
};

function bodFall()
{ var wad = world.animData;
  wad.dz -= 0.2;
  if (wad.z + wad.dz < 0)
  { wad.bod.translate(0, 0, -wad.z);
    animate();
  }
  else
  { wad.z += wad.dz;
    wad.bod.translate(0, 0, wad.dz);
    setTimeout(bodFall, 40);
  }
  wad.bod.checkGround();
}
