// Sub-type of Viewer for Alice's mirror
// Copyright (c) Graham Relf, UK, 2024
// www.grelf.net
'use strict';

function Me(x, y, z, bDegs, range, skyRGB, canvas)
{ Viewer.call(this, x, y, z, bDegs, range, skyRGB, canvas);
  
}
Me.prototype = Object.create(Viewer.prototype);
Me.prototype.constructor = Me;

Me.prototype.draw = function()//Override to avoid drawing me.bod
{ var t0 = new Date().getTime();
  if (this.pt.z < 90) this.g2.fillStyle = this.cssSky;
  else if (this.pt.z > 150) this.g2.fillStyle = '#000';
  else
  { var ratio = (150 - this.pt.z) / 60;
    this.g2.fillStyle = makeCssColour (Math.floor(this.sky.r * ratio),
      Math.floor(this.sky.g * ratio), Math.floor(this.sky.b * ratio));
  }
  this.g2.fillRect(0, 0, this.screenWd, this.screenHt);
  this.g2.font = "normal 32px serif";
  this.g2.fillStyle = "#69b";
  this.g2.fillText(this.URL, 8, 40);//B was "grelf.itch.io/the-green"
  this.targets = [];
  var sir = world.findShapesInRange(this);
  var sirL = sir.length, siri, sis;
  /* Underfloor pass:  //Not needed for Alice
  for (var i = 0; i < sirL; i++) // Furthest first
  { siri = sir [i];
    sis = siri.shape;
    if (sis.under)
    { sis.view (this, siri.fogNo);
      if (sis.isTarget)
        this.targets.push ({target:sis, maxX:sis.maxX, minX:sis.minX, maxY:sis.maxY, minY:sis.minY});
  } }*/
  // Background pass:
  for (var i = 0; i < sirL; i++) // Furthest first
  { siri = sir [i];
    sis = siri.shape;
    if (sis.background)
    { sis.view (this, siri.fogNo);
      if (sis.isTarget)
        this.targets.push ({target:sis, maxX:sis.maxX, minX:sis.minX, maxY:sis.maxY, minY:sis.minY});
  } }
  // Foreground pass:
  for (i = 0; i < sirL; i++) // Furthest first
  { siri = sir [i];
    sis = siri.shape;
    if (!sis.background /*&& !sis.under*/ && sis !== this.bod)//NOT DRAWING ME!
    { sis.view (this, siri.fogNo);
      if (sis.isTarget)
        this.targets.push ({target:sis, maxX:sis.maxX, minX:sis.minX, maxY:sis.maxY, minY:sis.minY});
  } }
  var dt = new Date ().getTime () - t0;
  this.showInfo (dt);
};