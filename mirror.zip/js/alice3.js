// Copyright (c) Graham Relf, UK, 2021-24
// www.grelf.net
// A demonstration of using the 2D graphics context of HTML5 to create animated
// 3D worlds from plain JavaScript without any other libraries or frameworks.
//3: Nov 2024
'use strict';

const RANGE = 100;

function run()
{ world = new World(RANGE, true);//foggy
  world.uiLocked = true;
  var canvas = document.getElementById("view");
  if (!canvas) { error('HTML page has no &lt;canvas id=&quot;view&quot;&gt;'); return; }
  canvas.width = window.innerWidth - 20;
  canvas.height = window.innerHeight - 120;
  //3:
  me = new Me(-50, -30, 10.5, 0, RANGE, {r:170, g:221, b:255}, canvas);
  me.URL = "grelf.itch.io/mirror";
  me.oldForward = me.forward;
  me.forward = function()
  { if (me.oldForward(me.step))//not blocked
    { me.bod.translate(me.step * Math.sin(me.bRad), me.step * Math.cos(me.bRad), 0);
      if (me.pt.distance(world.mirror.centre) < 10) into(world.mirror);
  } };
  me.oldTurn = me.turn;
  me.turn = function(rad)
  { me.oldTurn(rad);
    me.bod.rotateZ(rad * RAD2DEG);
  };
  me.oldUpOrDown = me.upOrDown;
  me.upOrDown = function(dz)
  { me.oldUpOrDown(dz);
    me.bod.translate(0, 0, dz);
  };
  //:3
  me.score = function() {};
  loadImage("tree1", "im/wood04.png", SPRITE);
  loadImage("tree2", "im/wood05.png", SPRITE);
  loadImage("tree3", "im/wood06.png", SPRITE);
  loadImage("tree4", "im/wood07.png", SPRITE);
  loadImage("tree5", "im/wood09.png", SPRITE);
  loadImage("snowdrop", "im/snowdrop.png", SPRITE);
  loadImage("egg", "im/egg.png", SPRITE);
  loadImage("qr", "im/qf00.png", SPRITE);
  loadImage("qg", "im/q0f0.png", SPRITE);
  loadImage("qb", "im/q00f.png", SPRITE);
  loadImage("qc", "im/q0ff.png", SPRITE);
  loadImage("qm", "im/qf0f.png", SPRITE);
  loadImage("qy", "im/qff0.png", SPRITE);
  loadImage("qw", "im/qfff.png", SPRITE);
  loadImage("qk", "im/q000.png", SPRITE);
  awaitLoaded();
}

function awaitLoaded()
{ if (!world.allImsLoaded()) setTimeout(awaitLoaded, 20);
  else
  { world.images["tree1neg"] = makeNegative(world.images["tree1"]);
    world.images["tree2neg"] = makeNegative(world.images["tree2"]);
    world.images["tree3neg"] = makeNegative(world.images["tree3"]);
    world.images["tree4neg"] = makeNegative(world.images["tree4"]);
    world.images["tree5neg"] = makeNegative(world.images["tree5"]);
    awaitNegated();
} }

function awaitNegated()
{ if (!world.allImsLoaded()) setTimeout(awaitNegated, 20);
  else
  { buildWorld();
    showButtons();
    makeKeyTable();
    hint = function(msg)//3: override
    { document.getElementById('hint').innerHTML = msg;
      say(removeBR(msg));
    };//:3
    me.showInfo = function(dt) // Override
    {
document.getElementById("info").innerHTML = me.toString();
/*document.getElementById ("score").innerHTML = 'Score: ' + me.myScore + 
    ' Cleaner: ' + world.cleaner.score;*/
document.getElementById("times").innerHTML = '(Frame ' + world.frameCount + 
    ',  drawn in ' + dt + 'ms)';
    };
    world.uiLocked = false;
    world.landed = function (shape) // Override
    { /*3:if (shape.daisy) // petal 
      { world.remove (shape);
        return; 
      }:3*/
      shape.isTarget = true; // fragment
      shape.response = function ()
      { world.remove (this);
//3        me.myScore += 10;
        if (world.cleaner) world.cleaner.aiming = false;
//3        hint ("10 points for cleaning");
      };
      this.targets.push (shape); 
    };
    hint(" Some objects respond to a click<br>or touch, in various ways.");//3
    animate();
  }
}

function removeBR(s)
{ var t = s.split('<');
  if (t.length === 1) return t[0];
  var u = t[0];
  for (var i = 1; i < t.length; i++)
  { var idx = t[i].indexOf('>');
    if (-1 === idx) alert("Hint string has < but no >");
    u += ' ' + t[i].substring(idx + 1);
  }
  return u;
}

function buildWorld()
{ world.tiles = [];
  world.TILE_SIZE = 10;
  var odd = true;
  for (var x = -RANGE + 5; x <= RANGE - 5; x += world.TILE_SIZE)
  { for (var y = -RANGE + 5; y <= RANGE - 5; y += world.TILE_SIZE)
    { var tile = createRectangle(x, y, 5, 5);
      tile.setColour(163, 156, 110);
      tile.setStroke(100, 100, 100);
      tile.background = true;
      world.add(tile);
      world.tiles.push({tile:tile, odd:odd});
      odd = !odd;
    }
    odd = !odd;
  }
  world.trees = [];//point obstacles: trees, wall corners
  for (var i = 0; i < 6; i++)
  { addTree(-90 + 10 * i, 50, 'tree5');
    addTree(50 + 10 * i, -60, 'tree2');
    addTree(55 + 6 * i, -40 + 8 * i, 'tree3');
    addTree(-50 + 7 * i, -50 - 7 * i, 'tree4');
    addTree(random(-80, -50), random(-100, -70), imFromN(Math.round(random (0, 4))));
  }
  var cube = new Cuboid(5, -25, 5, 5, 5, 5);
  cube.setSolid();
  cube.isTarget = true;
  cube.response = function() 
  { if (cube.centre.distance(me.pt) < 30) moveAway(cube);
    else hint("Get closer?");
  };
  cube.setCornersAsTrees();
  cube.setSolid();
  world.add(cube);
  var hex = createHexagon(-20, -30, 5);
  var rainbow = 
[
{r:96, g:96, b:96},//bottom
{r:96, g:96, b:96},//top
{r:142, g:0, b:142},//8e008e
{r:65, g:105, b:225},//4169e1
{r:0, g:142, b:0},//008e00
{r:255, g:255, b:0},//ff0
{r:255, g:142, b:0},//ff8e00
{r:255, g:0, b:0}//f00
];
  var prism1 = new Prism(hex.centre.x, hex.centre.y, 5, 5, hex.vertices, rainbow);
  world.add(prism1);
  for (i = 0; i < 4; i++)
  { var y = -70 - i * 9;
    var column = createStar(70, y, 11, 2, 2.25).extrude (30);
    column.setColour(190, 190, 190);
    column.setStroke(100, 100, 100);
    column.translate(0, 0, -1);
    world.add(column);
    var cap = createRectangle(70, y, 4, 4.5).extrude (1);
    cap.setColour(190, 190, 190);
    cap.setStroke(100, 100, 100);
    cap.translate(0, 0, 29);
    cap.isTarget = true;
    cap.response = function() { this.explode(); hint("BANG!"); };
    world.add(cap);
  }
  var leaf1 = createRectangle(-20, 15, 5, 5);
  leaf1.setColour(128, 128, 0);
  leaf1.faces[0].setAlpha(0.3);
  leaf1.rotateY(90);
  leaf1.translate(0, 0, 5);
  leaf1.setVelocity(0.01, 0.03, 0);
  leaf1.setAngular(2, 4, 6);
  leaf1.isTarget = true;
  leaf1.response = function() { this.explode(); hint("BANG!"); };
  world.add(leaf1);
  var leaf2 = createHexagon(15, -80, 5);
  leaf2.setColour(128, 128, 0);
  leaf2.rotateY(90);
  leaf2.translate(0, 0, 10);
  leaf2.setVelocity(-0.02, 0.03, 0);
  leaf2.setAngular(4, 5, 2);
  leaf2.setStroking(false);
  leaf2.explosive = true;
  leaf2.isTarget = true;
  leaf2.response = function() { this.explode(); hint("BANG!"); };
  world.add(leaf2);
  var leaf3 = createStar(0, 0, 5, 3, 7);
  leaf3.setColour(128, 128, 0);
  leaf3.rotateY(90);
  leaf3.translate(0, 0, 15);
  leaf3.setVelocity(0.03, -0.04, 0);
  leaf3.setAngular(2, 3, 4);
  leaf3.isTarget = true;
  leaf3.response = function() { this.explode(); hint("BANG!"); };
  world.add(leaf3);
  var dodeColours = [];
  for (i = 0; i < 12; i++)
  { dodeColours.push({r:random(120, 255), g:random(120, 255), b:random(120, 255)}); }
  var dodec = new Dodecahedron(-90, 0, 5, 5, dodeColours);
  dodec.setVelocity(0.2, 0.1, 0.75);
  dodec.setAngular(1, 5, 3);
  dodec.setFreeFall(true);
  dodec.setStroking(false);
  dodec.bouncy = true;
  dodec.isTarget = true;
  dodec.response = function() { this.velocity.dz += 0.25; hint("How high can a dodecahedron go?"); };
  world.add(dodec);
  var icos = new Icosahedron(10, -60, 7, 7);
  for (var i = 0; i < icos.faces.length; i++)
  { icos.faces[i].setColour(0, 200, 255);
    icos.faces[i].setAlpha(0.15);
  }
  icos.showAllFaces = true;
  icos.isTarget = true;
  icos.response = function() { hint("An icosahedron"); };
  world.add(icos);
  var bird1 = new Bird(1);
  bird1.translate(-90, -60, 32);
  bird1.setVelocity(0.12, -0.06, 0);
  bird1.rotateZ(30);
  bird1.setStroking(false);
  world.add(bird1);
  var bird2 = new Bird(1.4);
  bird2.translate(-90, 0, 34);
  bird2.setVelocity(0.15, 0.15, 0);
  bird2.rotateZ(-45);
  bird2.setStroking(false);
  world.add(bird2);
  var mirror = createRectangularMirror(-50, 0, 10, 7);
  mirror.rotateX(90);
  mirror.translate(0, 0, 12);//3 dz was 7);
  mirror.rotateZ(-45);
  mirror.isTarget = true;
  mirror.response = function() 
  { if (mirror.centre.distance(me.pt) < 30) into(this);
    else hint("Get closer? Then you can click the mirror or just walk through");//3
  };
  world.add(mirror);
  world.mirror = mirror;//3
  var board = new ChessBoard(0, 0, world.TILE_SIZE);//constrain queens
  var corners = [
    new Cuboid(board.minX, board.minY, 1, 0.2, 0.2, 1),
    new Cuboid(board.minX, board.maxY, 1, 0.2, 0.2, 1),
    new Cuboid(board.maxX, board.minY, 1, 0.2, 0.2, 1),
    new Cuboid(board.maxX, board.maxY, 1, 0.2, 0.2, 1)];
  for (var i = 0; i < corners.length; i++) world.add(corners[i]);
  world.board = board;//:3
  world.queens = 
   [new ChessQueen(5, 55, 'qr', 'R', board, mirror),
    new ChessQueen(25, 55, 'qg', 'G', board, mirror),
    new ChessQueen(55, 25, 'qg', 'G', board, mirror),//3
    new ChessQueen(5, 45, 'qg', 'G', board, mirror),//3
    new ChessQueen(75, 35, 'qb', 'B', board, mirror),//3
    new ChessQueen(15, 55, 'qb', 'B', board, mirror),//3
    new ChessQueen(45, 55, 'qb', 'B', board, mirror)];
  for (i = 0; i < world.queens.length; i++) world.add(world.queens[i]);
  world.bods = [
    createBod(40, 90, 5, 180, false),
    createBod(90, 40, 5, 270, false),
    createBod(me.pt.x, me.pt.y, 5, me.bRad * RAD2DEG)];//3
  for (i = 0; i < world.bods.length; i++) world.add(world.bods[i]);
  me.bod = world.bods[2];//3
  world.cleaner = createCleaner(0, 0, 4, 1.5);//3 radius was 5
  world.cleaner.isTarget = true;
  world.cleaner.response = function () 
  { hint("This robot cleans up exploded fragments"); };//3
  world.add(world.cleaner);
  world.house = {
    over: function() { return false; },
    outside: function() { return true; }};//Fudge for Alice (no house)
  var wall = new Cuboid(98, 15, 3, 2, 7.5, 3);
  wall.setColour(150, 100, 50);
  world.add(wall);
  var egg = new Sprite(98, 15, "egg");
  egg.centre.z = 6;
  egg.isTarget = true;
  egg.response = function()
  { egg.isTarget = false;
    world.animData = {egg:egg, dx:-1, dz:-1};
    eggFall();
  }
  world.add(egg);
  world.add(new Sprite(-20, -20, "snowdrop"));
}

function eggFall()
{ var wad = world.animData;
  var e = wad.egg;
  if (e.centre.x > 95) e.centre.x += wad.dx;
  if (e.centre.z > 0)
  { e.centre.z += wad.dz;
    setTimeout(eggFall, 40);
  }
  else
  { e.centre.z = 0;
    setTimeout(eggBreak, 500);
} }

function eggBreak()
{ world.remove(world.animData.egg);
  world.tiles[391].tile.setColour(255, 200, 0);
  hint("Splat!");
}

function moveAway(cube)//response
{ cube.removeCornersAsTrees();
  var vec = cube.centre.difference(me.pt);
  cube.translate(vec.dx, vec.dy, 0);
  for (var i = 0; i < world.solidWalls.length; i++)
  { if (world.solidWalls[i].face.parent === cube) 
    { world.solidWalls.splice(i, 1);
      i--;//Not just removing 1 face
  } }
  cube.setSolid();//Must redo this after each move
  cube.setCornersAsTrees();
  hint ("Don't push the cube off the edge");//<br>It could score you 1,000 points");
}

function imFromN(n)//For the random tree placement
{ switch (n)
  {
case 0: return 'tree1';
case 1: return 'tree2';
case 2: return 'tree3';
case 2: return 'tree4';
default: return 'tree5';
} }

function addTree(x, y, id)
{ var s = new Sprite(x, y, id);
  s.id = id;//3 - need to be able to get id after going tyhrough mirror
  world.add(s);
  world.trees.push({x:x, y:y, z:0});
}

Cuboid.prototype.removeCornersAsTrees = function()
{ var v = this.vertices;
  for (var i = 0; i < v.length; i++)
  { for (var j = world.trees.length - 1; j >= 0; j--)
    { var wtj = world.trees[j];
      if (wtj.x === v[i].x && wtj.y === v[i].y) world.trees.splice(j, 1);
  } }
};

Cuboid.prototype.setCornersAsTrees = function()
{ var v = this.vertices;
  for (var i = 0; i < v.length; i++) world.trees.push(v[i]);
};

function makeNegative(image)
{ world.nImsToLoad++;
  var wd = image.width, ht = image.height;
  var cnv = document.createElement("canvas");
  cnv.width = wd;
  cnv.height = ht;
  var g2 = cnv.getContext('2d');
  g2.drawImage(image, 0, 0, wd, ht);
  var imd = g2.getImageData(0, 0, wd, ht);
  for (var x = 0; x < wd; x++)
  { for (var y = 0; y < ht; y++)
    { var px = imd.getPixel(x, y);
      for (var i = 0; i < 3; i++) px[i] = 255 - px[i];//RGB
      imd.setPixel(x, y, px);
  } }
  g2.putImageData(imd, 0, 0);
  var im = new Image();
  im.loaded = false;
  im.onload = function()
  { im.foggy = new Array(8);
    im.foggy[0] = im;
    var cnv = document.createElement('canvas');
    cnv.width = im.width;
    cnv.height = im.height;
    var g2 = cnv.getContext('2d');
    g2.drawImage(im, 0, 0);
    im.foggy[0].data = g2.getImageData(0, 0, im.width, im.height);
    if (world.withFog) fogAll(im); // 1..7
    im.loaded = true; 
    world.nImsLoaded++;
  };
  im.src = cnv.toDataURL('image/png');
  return im;
}
