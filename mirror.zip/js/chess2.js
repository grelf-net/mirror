// Copyright (c) Graham Relf, UK, 2022-24
//2: Nov 24
// www.grelf.net
'use strict';

function ChessBoard(minX, minY, tileSize)
{ var boardSize = 8 * tileSize;
  this.minX = minX; this.maxX = minX + boardSize;
  this.minY = minY; this.maxY = minY + boardSize;
  this.tileSize = tileSize;
  this.occupied = new Array(8);//2
  for (var i = 0; i < 8; i++) this.occupied[i] = new Array(8);//2
}

ChessBoard.prototype.within = function(x, y)
{ return (x > this.minX && x < this.maxX
       && y > this.minY && y < this.maxY);
};

ChessBoard.prototype.getMapXY = function(x, y)
{ return {x:Math.floor((x - this.minX) / this.tileSize),
          y:Math.floor((y - this.minY) / this.tileSize)};
};

ChessBoard.prototype.getWorldXY = function(mapX, mapY)
{ return {x:this.minX + (mapX + 0.5) * this.tileSize,
          y:this.minY + (mapY + 0.5) * this.tileSize};
};

ChessBoard.prototype.view = function()
{ this.occupied = new Array(8);
  for (var i = 0; i < 8; i++) this.occupied[i] = new Array(8);
  me.g2.fillStyle = '#000';
  me.g2.fillRect (0, 0, 160, 160);
  for (var y = 0; y < 8; y++)
  { for (var x = 0; x < 8; x++)
    { if (isEven (x + y))
      { me.g2.fillStyle = '#fff';
        me.g2.fillRect(x * 20, y * 20, 20, 20);
  } } }
  for (i = 0; i < world.queens.length; i++)
  { var qi = world.queens[i];
    var x = qi.centre.x, y = qi.centre.y;
    if (this.within(x, y))
    { me.g2.strokeStyle = '#000';
      switch (qi.colour)
      {
case 'W': me.g2.fillStyle = '#fff'; break;
case 'R': me.g2.fillStyle = '#f00'; break;
case 'G': me.g2.fillStyle = '#0f0'; break;
case 'B': me.g2.fillStyle = '#44f';
          me.g2.strokeStyle = '#fff'; break;
case 'C': me.g2.fillStyle = '#0ff'; break;
case 'M': me.g2.fillStyle = '#f0f'; break;
case 'Y': me.g2.fillStyle = '#cc0'; break;
case 'K': me.g2.fillStyle = '#000'; break;
      }
      var xy = this.getMapXY(x, y);
      this.occupied[xy.x][xy.y] = qi;
      me.g2.beginPath();
      me.g2.arc((xy.x + 0.5) * 20, ((7 - xy.y) + 0.5) * 20, 8, 0, TWO_PI);
      me.g2.fill();
      me.g2.stroke();
  } }
  for (i = 0; i < world.bods.length; i++)
  { var bi = world.bods[i];
    var x = bi.centre.x, y = bi.centre.y;
    if (this.within(x, y))
    { var xy = this.getMapXY(x, y);
      this.occupied[xy.x][xy.y] = bi;
      me.g2.fillStyle = '#7e7';
      me.g2.fillRect((xy.x + 0.25) * 20, ((7 - xy.y) + 0.25) * 20, 10, 10);
  } }
  var x = me.pt.x, y = me.pt.y; 
  if (this.within(x, y))
  { var xy = this.getMapXY(x, y);
    this.occupied[xy.x][xy.y] = me;
    me.g2.fillStyle = '#999';
    me.g2.fillRect((xy.x + 0.25) * 20, ((7 - xy.y) + 0.25) * 20, 10, 10);
  }
};

function isEven(x) { return ((x & 1) === 0); }

function ChessPiece(xCentre, yCentre, imageName, kindChar, colourChar, board)
{ Sprite.call(this, xCentre, yCentre, imageName);
  this.kind = kindChar;//eg 'Q' for Queen
  this.colour = colourChar;//eg 'R' for Red, WRGBCMYK
  this.board = board;
  this.movable = true;
  this.dx = 0;
  this.dy = 0;
}
ChessPiece.prototype = Object.create(Sprite.prototype);
ChessPiece.prototype.constructor = ChessPiece;

ChessPiece.prototype.view = function(me, fogNo)//2
{ if (world.mirror.through)
  { Sprite.prototype.view.call(this, me, fogNo);
} };

ChessPiece.prototype.update = function()//Move
{ if (0 === this.dx && 0 === this.dy) return false;
  var newX = this.centre.x + this.dx;
  var newY = this.centre.y + this.dy;
  if (!this.board.within(newX, newY)) return false;
  var xy = this.board.getMapXY(newX, newY);
  var obj = this.board.occupied[xy.x][xy.y];
  if (obj)
  { if (obj instanceof Bod || obj instanceof Viewer) return false;
    if (!this.mergeable(this.colour + obj.colour)) return false;// obj must be another Q
  }
  this.centre.x = newX;
  this.centre.y = newY;
  return true;
};

ChessPiece.prototype.mergeable = function(cc)
{ switch (cc)
  { case 'RG': case 'RB': case 'RC': case 'CR':
    case 'GR': case 'GB': case 'GM': case 'MG':
    case 'BR': case 'BG': case 'BY': case 'YB': return true;
  }
  return false;
};

function ChessQueen(xCentre, yCentre, imageName, colourChar, board)
{ ChessPiece.call(this, xCentre, yCentre, imageName, 'Q', colourChar, board); }
ChessQueen.prototype = Object.create(ChessPiece.prototype);
ChessQueen.prototype.constructor = ChessQueen;

ChessQueen.prototype.update = function()//move
{ if (Math.random () > 0.008) return;//Not every frame!
  this.dx = randomInt(-1, 1) * world.TILE_SIZE;
  this.dy = randomInt(-1, 1) * world.TILE_SIZE;
  if (ChessPiece.prototype.update.call(this))
  { if (Math.random() > 0.95) this.checkSplit();
    this.checkMerge();
  }
};

function randomInt(min, max)
{ return Math.round(random (min - 0.5, max + 0.5)); }

ChessQueen.prototype.checkSplit = function()
{ switch (this.colour)
  {
case 'C': this.split('G', 'B'); return;
case 'M': this.split('R', 'B'); return;
case 'Y': this.split('R', 'G'); return;
case 'W': var r = Math.random();
    if (r < 0.333) this.split('R', 'C');
    else if (r < 0.667) this.split('G', 'M');
    else this.split('B', 'Y');
  }
};

ChessQueen.prototype.split = function(c1, c2)
{ var wq = world.queens, j = -1;
  for (var i = 0; i < wq.length; i++)
  { if (wq[i] === this) j = i; }
  if (j >= 0)
  { var newQ1 = new ChessQueen(this.centre.x + this.board.tileSize, this.centre.y,
        'q' + c1.toLowerCase(), c1, this.board);
    var newQ2 = new ChessQueen(this.centre.x - this.board.tileSize, this.centre.y,
        'q' + c2.toLowerCase(), c2, this.board);
    world.remove(this);
    wq.splice(j, 1);
    wq.push(newQ1);
    wq.push(newQ2);
    world.add(newQ1);
    world.add(newQ2);
  }
};

ChessQueen.prototype.checkMerge = function()
{ var wq = world.queens, ql = wq.length;
  for (var i = 0; i < ql; i++)
  { for (var j = 0; j < ql; j++)
    { if (i !== j && wq[i].centre.x === wq[j].centre.x && wq[i].centre.y === wq[j].centre.y)
      { switch (wq[i].colour + wq[j].colour)
        {
case 'RG':
case 'GR': replaceQueens(i, j, 'qy', 'Y'); return;
case 'RB':
case 'BR': replaceQueens(i, j, 'qm', 'M'); return;
case 'BG':
case 'GB': replaceQueens(i, j, 'qc', 'C'); return;
case 'RC':
case 'CR':
case 'MG':
case 'GM':
case 'YB':
case 'BY': replaceQueens(i, j, 'qw', 'W'); return;
default: this.dx = -this.dx;
         this.dy = -this.dy;
         this.update();
  } } } }
};

function replaceQueens(i, j, imageName, colourChar)
{ var wq = world.queens, wqi = wq[i], wqj = wq[j];
  var x = wqi.centre.x, y = wqi.centre.y, board = wqi.board;
  world.remove(wqi);
  world.remove(wqj);
  wq.splice(i, 1);
  if (i < j) j--;
  wq.splice(j, 1);
  var newQ = new ChessQueen(x, y, imageName, colourChar, board);
  wq.push(newQ);
  world.add(newQ);
}
