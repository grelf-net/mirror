// Speaking text
// Copyright (c) Graham Relf, UK, 2024
// www.grelf.net
// Based on https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API/Using_the_Web_Speech_API
'use strict';

const SYNTH = window.speechSynthesis, VOICES = speechSynthesis.getVoices();

function say(text)
{ if (!SYNTH)
  { console.log("No speech synthesiser available"); return; }
  var utter = new SpeechSynthesisUtterance(text);
  for (var i = 0; i < VOICES.length; i++)
  { if (-1 !== VOICES[i].name.indexOf("George"))
    { utter.voice = VOICES[i];
  } }
  SYNTH.speak(utter);
}
