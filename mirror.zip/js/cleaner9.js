// Copyright (c) Graham Relf, UK, 2020
// www.grelf.net
'use strict';

// Cleaner is a shape (extruded polygon)
function createCleaner (xCentre, yCentre, radius, height)
{ var cl = createRegularPolygon (xCentre, yCentre, 16, radius).extrude (height); // a Prism
  cl.radius = radius;
  cl.radiusSq = radius * radius;
  cl.radiusSq16 = 16 * cl.radiusSq;
  cl.setStroking (false);
  cl.faces [1].setColour (255, 80, 0);// top
  for (var i = 2; i < cl.faces.length; i++) cl.faces [i].setColour (240, 60, 0);
  cl.setVelocity (0.1, 0, 0);
  cl.velocity.rotateZ (random (0, 359));
  cl.aiming = false;
  cl.paused = false;//8
  cl.score = 0;
  cl.bounce = function()//9:
  { this.velocity.reverse();
    this.translate(10 * this.velocity.dx, 10 * this.velocity.dy, 0);//Big bounce
    this.velocity.rotateZ(random(-70, 70));//Random turn avoids getting stuck
  };//:9
  cl.update = function()//clean
  { if (this.paused) return;//8
    // Reflect off edge of world:
    if (this.centre.x > world.range - this.radius) 
    { this.velocity.dx = -Math.abs (this.velocity.dx);
      this.centre.x = world.range - this.radius;
    }
    else if (this.centre.x < -world.range + this.radius)
    { this.velocity.dx = Math.abs (this.velocity.dx);
      this.centre.x = -world.range + this.radius;
    }
    if (this.centre.y > world.range - this.radius) 
    { this.velocity.dy = -Math.abs (this.velocity.dy);
      this.centre.y = world.range - this.radius;
    }
    else if (this.centre.y < -world.range + this.radius)
    { this.velocity.dy = Math.abs (this.velocity.dy);
      this.centre.y = -world.range + this.radius;
    }
    var newPt = new Point3D (this.centre.x + this.velocity.dx,
                             this.centre.y + this.velocity.dy, this.centre.z);
    for (var i = 0; i < world.queens.length; i++)
    { if (newPt.distance(world.queens[i].centre) < this.radius)
      { this.bounce();
        return;
    } }
    for (var i = 0; i < world.bods.length; i++)
    { if (newPt.distance(world.bods[i].centre) < this.radius)
      { this.bounce();
        return;
    } }
    var hitTree = false;
    if (!this.aiming)
    { for (var i = 0; i < world.trees.length && !hitTree; i++)
      { if (newPt.distance (world.trees [i]) < this.radius)
        { hitTree = true;
          this.bounce();
      } }
      //Reverse if too close to solid wall:
      if (!hitTree)
      { if (world.house.over (this.centre, this.radius)) this.velocity.reverse ();
        else for (i = 0; i < world.solidWalls.length; i++)
        { if (world.solidWalls [i].tooClose (newPt)) 
          { if (world.solidWalls [i].minY) this.velocity.dx = -this.velocity.dx; // wall parallel to y-axis
            else this.velocity.dy = -this.velocity.dy;
            this.translate (this.velocity.dx, this.velocity.dy, 0);
            return;
    } } } }
    if ((world.frameCount & 0x3ff) === 64) // Every 64
      this.velocity.rotateZ (random (-45, 45)); // Turn
    if (!hitTree)
    { this.translate (this.velocity.dx, this.velocity.dy, 0);
      for (i = 0; i < world.targets.length; i++)
      { var ti = world.targets [i];
        if (ti.isFragment)
        { var dx = ti.centre.x - this.centre.x;
          var dy = ti.centre.y - this.centre.y;
          var d2 = dx * dx + dy * dy;
          if (d2 <= this.radiusSq)
          { world.remove (ti);
            this.score += 100;
            this.aiming = false;
//9            hint ("Cleaner's score: " + this.score);
            return;
          }
          else if (d2 <= this.radiusSq16) // within 4 radii
          { var vx = this.velocity.dx, vy = this.velocity.dy;
            var scale = Math.sqrt ((vx * vx + vy * vy) / d2);
            this.setVelocity (dx * scale, dy * scale, 0); // Move towards
            this.aiming = true;
            return;
    } } } }
  };
  return cl;
}

