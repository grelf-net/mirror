// Copyright (c) Graham Relf, UK, 2020
// www.grelf.net
'use strict';

function Bird (scale)
{ Shape.call (this);
  this.centre = new Point3D (0, 0, 0); // translate later
  this.scale = scale;
  var nFaces = 5; // 2 for each wing + body
  if (arguments.length > 1) this.fillColours = arguments [1];
  else
  { this.fillColours = [];
    for (var i = 0; i < nFaces; i++) this.fillColours.push ({r:80, g:80, b:80}); // grey #555
  }
  this.vertices = 
  [ // Left wing:
new Point3D (-0.4, 0, 0),//0 (body)
new Point3D (0.3, 0, 0),//1 (body)
new Point3D (0.3, 0.3, 0),//2 (mid)
new Point3D (-0.3, 0.3, 0),//3 (mid)
new Point3D (0, 0.7, 0),//4 (tip)
    // Right wing:
new Point3D (-0.4, 0, 0),//5 (body)
new Point3D (0.3, 0, 0),//6 (body)
new Point3D (0.3, -0.3, 0),//7 (mid)
new Point3D (-0.3, -0.3, 0),//8 (mid)
new Point3D (0, -0.7, 0),//9 (tip)
// Body profile:
new Point3D (-1.2, 0,-0.1),//10 (tail)
new Point3D (0.4, 0, 0.1),//11
new Point3D (0.6, 0, 0.3),//12
new Point3D (1.1, 0, 0.1),//13
new Point3D (0.7, 0, -0.1)//14
  ];
  for (i = 0; i < this.vertices.length; i++)
  { var vi = this.vertices [i];
    vi.x *= scale; vi.y *= scale; vi.z *= scale;
  }
  this.makeFace (0, [0, 1, 2, 3]);
  this.makeFace (1, [2, 3, 4]);
  this.makeFace (2, [5, 6, 7, 8]);
  this.makeFace (3, [7, 8, 9]);
  this.makeFace (4, [10, 11, 12, 13, 14]);
  this.background = false;
  this.freeFall = false;
  this.velocity = new Vector3D (0, 0, 0);
  this.angular = new Vector3D (0, 0, 0);
  this.movable = true; // See this.fly()
  this.isTarget = true;
  this.response = function () { hint ('We are wildlife.<br>Leave us alone!'); };
  this.t = 0; this.T = 60; // time steps
  this.a = 0; this.dA = 2 * Math.PI / this.T; // angles
}

Bird.prototype = Object.create (Shape.prototype);
Bird.prototype.constructor = Bird;

Bird.prototype.update = function () // fly
{ var midZ = this.centre.z + this.scale * 0.25 * Math.sin (this.a);
  this.vertices [2].z = midZ;
  this.vertices [3].z = midZ;
  this.vertices [7].z = midZ;
  this.vertices [8].z = midZ;
  var tipZ = this.centre.z + this.scale * 0.35 * Math.sin (this.a) - 0.25;
  this.vertices [4].z = tipZ;
  this.vertices [9].z = tipZ;
  this.translate (this.velocity.dx, this.velocity.dy, this.velocity.dz);
  // Reflect off edge of world:
  if (this.centre.x > world.range || this.centre.x < -world.range)
  { var ai = Math.atan2 (this.velocity.dy, this.velocity.dx); // Incidence
    this.rotateZ (-(Math.PI - 2 * ai) * RAD2DEG);
    this.velocity.dx = -this.velocity.dx;
  }
  if (this.centre.y > world.range || this.centre.y < -world.range)
  { ai = Math.atan2 (this.velocity.dx, this.velocity.dy);
    this.rotateZ ((Math.PI - 2 * ai) * RAD2DEG);
    this.velocity.dy = -this.velocity.dy;
  }
  this.t++; this.a += this.dA;
  if (this.t > this.T)
  { this.t = 0; this.a = 0; 
    var drift = random (-1, 1);
    this.rotateZ (drift);
    this.velocity.rotateZ (drift);
  }
};

// Slighty different from a solid shape: all faces visible
Bird.prototype.view = function (me, fogNo)
{ this.minX = null; this.maxX = null; this.minY = null; this.maxY = null;
  var nFaces = this.faces.length, visible = new Array (nFaces);
  for (var i = 0; i < nFaces; i++)
  { var face = this.faces [i];
    var d = face.centre.distance (me.pt);
    visible [i] = {d:d, face:face};
  }
  visible.sort (function (a, b) {return a.d - b.d;}); // Ascending distance
  for (i = nFaces - 1; i >= 0; i--) // Furthest first
  { visible [i].face.view (me, fogNo); }
};
