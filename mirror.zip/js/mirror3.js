// Copyright (c) Graham Relf, UK, 2021-24
// www.grelf.net
//3: Nov 2024
'use strict';

// Created in an x-y plane, z = 0.
// Rotate about x or y to stand up.
function Mirror(xCentre, yCentre, vertices)
{ Polygon.call(this, xCentre, yCentre, vertices);
  this.canvas = document.createElement("canvas");//off screen
  this.canvas.width = me.canvas.width;
  this.canvas.height = me.canvas.height;
  this.g2 = this.canvas.getContext("2d");
  this.showThis = true;
  this.through = false;
  //Reflected me must be type Viewer, not Me, so me.bod is drawn
  this.refl = new Viewer(0, 0, 10.5, 0, RANGE, me.sky, this.canvas);//3
  this.refl.canvas.removeEventListener('click', onClick);//3
  this.refl.score = function() {};//3
}
Mirror.prototype = Object.create(Polygon.prototype);
Mirror.prototype.constructor = Mirror;

function createRectangularMirror (xCentre, yCentre, halfwidth, halfdepth)
{ return new Mirror(xCentre, yCentre, 
  [ {x:xCentre + halfwidth, y:yCentre + halfdepth, z:0},
    {x:xCentre - halfwidth, y:yCentre + halfdepth, z:0},
    {x:xCentre - halfwidth, y:yCentre - halfdepth, z:0},
    {x:xCentre + halfwidth, y:yCentre - halfdepth, z:0}
  ]);
}

Mirror.prototype.view = function(dummy, fogNo)//override Shape.view, dummy not used
{ if (!this.showThis) return;
    
  //Reflect viewer (global me) in mirror plane:
  var f = this.faces[0];
  f.setUnitNormal();
  var meD = f.getPoint3DDistance(me.pt);
  var scale = -2 * meD;
  var fun = f.unitNormal;
  var imPt = me.pt.newOffsetPt(scale * fun.dx, scale * fun.dy, scale * fun.dz);
  var imdb = imPt.distanceAndBearing(this.centre);
//3: var imMe = new Viewer(imPt.x, imPt.y, imPt.z, imdb.b * RAD2DEG, RANGE, me.sky, this.canvas);
  var imMe = this.refl;//3
  imMe.pt.x = imPt.x;
  imMe.pt.y = imPt.y;
  imMe.pt.z = imPt.z;
  imMe.bRad = imdb.b;//:3
  //Draw the world as seen by reflected me, in offscreen canvas:
  //Get screen bounds of mirror as seen by reflected me:
  var edgeIm = this.getEdge(imMe);
  if (!edgeIm.ok) return;//Abort if too close to mirror

  imMe.showThis = false;//Don't draw the mirror - prevent recursion
  imMe.drawReflection(imdb.d);//(In hidden canvas. Method defined in this file)
  this.showThis = true;//but it will be seen in the real view

  //Get screen bounds of mirror as seen by real me:
  var edgeMe = this.getEdge(me);
  //Abort if too close to mirror:
  if (!edgeMe.ok) return;
  
  //For mirror as a target:
  this.minX = edgeMe.xL; this.maxX = edgeMe.xR;
  this.minY = Math.min(edgeMe.yLT, edgeMe.yRT);
  this.maxY = Math.max(edgeMe.yLB, edgeMe.yRB);

  //Get drawn data within the bounds:
  var wd = edgeIm.xR - edgeIm.xL;
  if (wd < 3)//Seen edge-on: no reflection
  { me.g2.beginPath();
    me.g2.moveTo(edgeMe.xL, edgeMe.yLB);
    me.g2.lineTo(edgeMe.xL, edgeMe.yLT);
    me.g2.strokeStyle = fog(0, 0, 0, fogNo);
    me.g2.stroke();
    return;
  }
  var ht = Math.max(edgeIm.yLB - edgeIm.yLT, edgeIm.yRB - edgeIm.yRT);
  var x0 = edgeIm.xL;
  var y0 = Math.min(edgeIm.yLT, edgeIm.yRT);
  var reflImData = this.g2.getImageData(x0, y0, wd, ht); // Has to be rectangular

  //Adjust edge relative to reflImData:
  edgeIm.xL = 0;    edgeIm.xR = wd;
  edgeIm.yLT -= y0; edgeIm.yRT -= y0;
  edgeIm.yLB -= y0; edgeIm.yRB -= y0;

  // Draw the image data, reflected horizontally, but only for points within the path:
  var worldImData = me.g2.getImageData(0, 0, me.canvas.width, me.canvas.height);
  fillMirror(edgeIm, reflImData, edgeMe, worldImData);
  me.g2.putImageData(worldImData, 0, 0);

  // Draw rim:
  me.g2.beginPath();
  me.g2.moveTo(edgeMe.xL, edgeMe.yLB);
  me.g2.lineTo(edgeMe.xL, edgeMe.yLT);
  me.g2.lineTo(edgeMe.xR, edgeMe.yRT);
  me.g2.lineTo(edgeMe.xR, edgeMe.yRB);
  me.g2.closePath();
  me.g2.strokeStyle = fog(0, 0, 0, fogNo);
  me.g2.stroke();
};

Mirror.prototype.getEdge = function(viewer)
{ var edge = { ok:true }, nv = this.vertices.length, sxy = new Array (nv);
  sxy[0] = viewer.getScreenXYD(this.vertices[0]);
  edge.xL = sxy[0].x, edge.xR = sxy[0].x;//Left & Right
  for (var i = 1; i < nv; i++)
  { sxy[i] = viewer.getScreenXYD(this.vertices[i]);
    if (sxy[i].x < edge.xL) edge.xL = sxy[i].x;
    else if (sxy[i].x > edge.xR) edge.xR = sxy[i].x;
  }
  var yL = [], yR = [];
  for (i = 0; i < nv; i++)
  { if (sxy[i].x === edge.xL) yL.push(sxy[i].y);
    else if (sxy[i].x === edge.xR) yR.push(sxy[i].y);
  }
  if (yL.length !== 2 || yR.length !== 2) { edge.ok = false; return edge; }//Too close to mirror
  if (yL[0] < yL[1]) { edge.yLT = yL[0]; edge.yLB = yL[1]; }//Left Top & Bottom
  else { edge.yLT = yL[1]; edge.yLB = yL[0]; }
  if (yR[0] < yR[1]) { edge.yRT = yR[0]; edge.yRB = yR[1]; }//Right Top & Bottom
  else { edge.yRT = yR[1]; edge.yRB = yR[0]; }
  if (edge.xL < 0) edge.xL = 0;
  else edge.xL = Math.round(edge.xL);
  if (edge.xR >= this.canvas.width) edge.xR = this.canvas.width - 1;
  else edge.xR = Math.round(edge.xR);
  if (edge.yLT < 0) edge.yLT = 0;
  else edge.yLT = Math.round(edge.yLT);
  if (edge.yLB >= this.canvas.height) edge.yLB = this.canvas.height - 1;
  else edge.yLB = Math.round(edge.yLB);
  if (edge.yRT < 0) edge.yRT = 0;
  else edge.yRT = Math.round(edge.yRT);
  if (edge.yRB >= this.canvas.height) edge.yRB = this.canvas.height - 1;
  else edge.yRB = Math.round(edge.yRB);
  return edge;
};

function fillMirror(srcEdge, srcData, dstEdge, dstData)
{ var srcWd = srcEdge.xR - srcEdge.xL, dstWd = dstEdge.xR - dstEdge.xL;
  var recipDstWd = 1 / dstWd;
  var dSrcX = srcWd * recipDstWd;//dDstX = 1 always
  var srcYT = srcEdge.yRT, dSrcYT = (srcEdge.yLT - srcEdge.yRT) * recipDstWd;
  var srcYB = srcEdge.yRB, dSrcYB = (srcEdge.yLB - srcEdge.yRB) * recipDstWd;
  //reversed:
  var dstYT = dstEdge.yLT, dDstYT = (dstEdge.yRT - dstEdge.yLT) * recipDstWd;
  var dstYB = dstEdge.yLB, dDstYB = (dstEdge.yRB - dstEdge.yLB) * recipDstWd;
  for (var dstX = dstEdge.xL, srcX = srcEdge.xR; dstX <= dstEdge.xR; dstX++, srcX -= dSrcX)
  { var dSrcY = (srcYB - srcYT) / (dstYB - dstYT);//dDstY = 1 always
    for (var dstY = dstYT, srcY = srcYT; dstY < dstYB; dstY++, srcY += dSrcY)
    { //3 dstData.setPixel(dstX, dstY, srcData.getPixel(srcX, srcY));
      var iSrc = (srcData.width * (srcY | 0) + (srcX | 0)) * 4;
      var iDst = (dstData.width * (dstY | 0) + (dstX | 0)) * 4;
      dstData.data[iDst] = srcData.data[iSrc];//R
      iDst++; iSrc++;
      dstData.data[iDst] = srcData.data[iSrc];//G
      iDst++; iSrc++;
      dstData.data[iDst] = srcData.data[iSrc];//B
      //Ignore A
    }
    srcYT += dSrcYT; dstYT += dDstYT;
    srcYB += dSrcYB; dstYB += dDstYB;
} }

//A version of Viewer.draw that ignores shapes closer than the mirror
Viewer.prototype.drawReflection = function(mirrorD)
{ if (this.pt.z < 90) this.g2.fillStyle = this.cssSky;
  else if (this.pt.z > 150) this.g2.fillStyle = '#000';
  else
  { var ratio = (150 - me.pt.z) / 60;
    this.g2.fillStyle = makeCssColour(Math.floor(this.sky.r * ratio),
      Math.floor (this.sky.g * ratio), Math.floor(this.sky.b * ratio));
  }
  this.g2.fillRect(0, 0, this.screenWd, this.screenHt);
  var sir = world.findShapesInRange(this);
  var sirL = sir.length;
  // Background pass:
  for (var i = 0; i < sirL; i++)//Furthest first
  { var siri = sir[i];
    if (siri.shape.background) siri.shape.view(this, siri.fogNo);
  }
  // Foreground pass:
  for (i = 0; i < sirL; i++)//Furthest first
  { siri = sir[i];
    if (siri.d > mirrorD
     && !siri.shape.background && !siri.shape.under)
    { var ss = siri.shape;//Must save target bounds:
      var minX = ss.minX, maxX = ss.maxX;
      var minY = ss.minY, maxY = ss.maxY;
      ss.view (this, siri.fogNo);//And restore:
      ss.minX = minX; ss.maxX = maxX;
      ss.minY = minY; ss.maxY = maxY;
  } }
};

function into(mirror)
{ world.uiLocked = true;
  world.animPaused = true;
  var route = mirror.centre.difference(me.pt);
  var nSteps = 30;//3
  world.animData = 
    {dx:route.dx / nSteps, dy:route.dy / nSteps, pt:me.pt.clone(),
     mirror:mirror, nSteps:nSteps + 50};//Go beyond
  document.getElementById("buttons").innerHTML = "&nbsp; Just enjoy the ride...";
  hint('');
  moveInto();
}

function moveInto()
{ var wad = world.animData;
  me.pt.x += wad.dx;
  me.pt.y += wad.dy;
  me.draw ();
  wad.nSteps--;
  if (wad.nSteps > 0) requestAnimationFrame(moveInto); //3 setTimeout(moveInto, 10);
  else
  { wad.mirror.through = !wad.mirror.through;
    var wt = world.tiles;
    if (wad.mirror.through)
    { for (var i = 0; i < wt.length; i++)
      { var wti = wt[i];
        if (wti.odd) wti.tile.setColour (0, 0, 0);
        else wti.tile.setColour(255, 255, 255);
        var wc = wti.tile.centre, wb = world.board;//3:
        if (wc.x > wb.minX && wc.x < wb.maxX && wc.y > wb.minY && wc.y < wb.maxY)
        { wti.tile.setStroke(0, 255, 255); }//:3
        else wti.tile.setStroke(0, 0, 0);
      }
      for (var i = 0; i < world.shapes.length; i++)//3:
      { var wsi = world.shapes[i];
        if (wsi instanceof Sprite)
        { var sid = wsi.id;
          if (sid && sid.startsWith("tree"))
          { wsi.id = sid + "neg";
            wsi.image = world.images[wsi.id];
      } } }//:3
    }
    else
    { for (var i = 0; i < wt.length; i++)
      { wt[i].tile.setColour(163, 156, 110); 
        wt[i].tile.setStroke(100, 100, 100);
      }
      for (var i = 0; i < world.shapes.length; i++)//3:
      { var wsi = world.shapes[i];
        if (wsi instanceof Sprite)
        { var sid = wsi.id;
          if (sid && sid.endsWith("neg"))
          { wsi.id = sid.substring(0, sid.length - 3);
            wsi.image = world.images[wsi.id];
      } } }//:3
    }
    wad.mirror.minX = null; wad.mirror.maxX = null;//No longer a target
    wad.mirror.minY = null; wad.mirror.maxY = null;
    me.bod.translate(me.pt.x - wad.pt.x, me.pt.y - wad.pt.y, 0);//3
    world.uiLocked = false;
    world.animPaused = false;
    hint("How might we capture the red queen?");//3
    document.getElementById("view").focus();
    showButtons();
    animate();
} }
